function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bIvGvBY6sh":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

