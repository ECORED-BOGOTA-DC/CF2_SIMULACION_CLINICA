function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5aJ44XACMQZ":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

