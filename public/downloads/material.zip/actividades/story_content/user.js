function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5tT4jqaIP9C":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

